import sqlalchemy
from .db_session import SqlAlchemyBase

class City(SqlAlchemyBase):
    __tablename__ = 'city'

    city_id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True, autoincrement=True)
    city_name = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    city_map = sqlalchemy.Column(sqlalchemy.BLOB)