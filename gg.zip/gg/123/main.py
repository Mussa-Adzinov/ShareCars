from flask import Flask, render_template, redirect, request, abort
from flask_login import LoginManager, login_user, current_user, logout_user, login_required
from data import db_session
from data.news import News
from data.cars import Cars
from data.users import User
from forms.user import RegisterForm, LoginForm
from forms.filter import YearForm, BrandForm, PriceForm, WheelForm, CityForm
from forms.oplata import EditForm
from forms.news import NewsForm
from sqlalchemy import and_

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'
login_manager = LoginManager()
login_manager.init_app(app)


def main():
    db_session.global_init("db/blogs.db")
    app.run(port=1588, host='127.0.0.1')


@app.route("/rent")
def rent():
    db_sess = db_session.create_session()
    cars = db_sess.query(Cars)
    return render_template('cars.html', cars=cars, title='Доступные автомобили')

@app.route("/profile", methods=['GET'])
@login_required
def profile():
    return render_template('profile.html', user=current_user)

@app.route("/blog")
def index():
    db_sess = db_session.create_session()
    news = db_sess.query(News)
    return render_template("index.html", news=news)

@app.route('/', methods=['GET', 'POST'])
def start():
    return render_template('start.html')


@app.route('/reg', methods=['GET', 'POST'])
def reqister():
    form = RegisterForm()
    if form.validate_on_submit():
        checkbox_value = request.form.get('checkbox')
        if checkbox_value != 'checked':
            return render_template('register.html', title='Регистрация', form=form,
                                   message="Примите политику конфиденциальности")
        if form.password.data != form.password_again.data:
            return render_template('register.html', title='Регистрация', form=form,
                                   message="Пароли не совпадают")
        db_sess = db_session.create_session()
        if db_sess.query(User).filter(User.email == form.email.data).first():
            return redirect('/login')
        user = User(
            name=form.name.data,
            email=form.email.data,
            about=form.about.data
        )
        user.set_password(form.password.data)
        db_sess.add(user)
        db_sess.commit()
        return redirect('/rent')
    return render_template('register.html', title='Регистрация', form=form)

@app.route('/politik')
def politik():
    return render_template('politik.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        user = db_sess.query(User).filter(User.email == form.email.data).first()
        if user and user.check_password(form.password.data):
            login_user(user, remember=form.remember_me.data)
            return redirect("/rent")
        return render_template('login_2.html',
                               message="Неправильный логин или пароль",
                               form=form)
    return render_template('login_2.html', title='Авторизация', form=form)

@login_manager.user_loader
def load_user(user_id):
    db_sess = db_session.create_session()
    return db_sess.query(User).get(user_id)

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect("/")
@app.route('/v')
@login_required
def v():
    login_user()
    return redirect("/rent")
@app.route('/news',  methods=['GET', 'POST'])
@login_required
def add_news():
    form = NewsForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        news = News()
        news.title = form.title.data
        news.content = form.content.data
        news.is_private = form.is_private.data
        current_user.news.append(news)
        db_sess.merge(current_user)
        db_sess.commit()
        return redirect('/blog')
    return render_template('news.html', title='Добавление отзыва',
                           form=form)
@app.route('/info/<int:id>', methods=['GET'])
@login_required
def info(id):
    db_sess = db_session.create_session()
    cars = db_sess.query(Cars).filter(Cars.id == id)
    return render_template('info.html', cars=cars)

@app.route('/edit_profile', methods=['GET', 'POST'] )
def edit():
    form = EditForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        if request.method == "GET":
            if db_sess.query(User).filter(User.id == 3).first():
                user = User(
                  card=form.card.data,
                )
                user.set_cvc(form.cvc.data)
                db_sess.add(user)
                db_sess.commit()
        return redirect('/profile')
    return render_template('oplata.html',
                           title='Добавление способа оплаты',
                           form=form
                           )

@app.route('/news_delete/<int:id>', methods=['GET', 'POST'])
@login_required
def news_delete(id):
    db_sess = db_session.create_session()
    news = db_sess.query(News).filter(News.id == id,
                                      News.user == current_user
                                      ).first()
    if news:
        db_sess.delete(news)
        db_sess.commit()
    else:
        abort(404)
    return redirect('/rent')


@app.route('/rent/auto<int:id>')
@login_required
def rent_auto(id):
    db_sess = db_session.create_session()
    cars = db_sess.query(Cars).filter(Cars.id == id)

    return render_template('rent.html',
                           title='Аренда',
                           cars=cars
                           )
@app.route('/rent/year', methods=['GET', 'POST'])
@login_required
def year():
    form = YearForm()
    if form.validate_on_submit():
        if form.year.data == '':
            return render_template('year.html', form=form, title='Автомобили с фильтром год', message='Выберите год')
        db_sess = db_session.create_session()
        if db_sess.query(Cars).filter(Cars.year == form.year.data):
            cars = db_sess.query(Cars).filter(Cars.year == form.year.data)
            return render_template('cars.html', cars=cars, title='Автомобили с фильтром год')
    return render_template('year.html', form=form, title='Автомобили с фильтром год')

@app.route('/rent/brand', methods=['GET', 'POST'])
@login_required
def brand():
    form = BrandForm()
    if form.validate_on_submit():
        if form.brand.data == '':
            return render_template('brand.html', form=form, title='Автомобили с фильтром марка',
                                   message='Выберите марку автомобиля')
        db_sess = db_session.create_session()
        if db_sess.query(Cars).filter(Cars.car_brand == form.brand.data):
            cars = db_sess.query(Cars).filter(Cars.car_brand == form.brand.data)
            return render_template('cars.html', cars=cars, title='Автомобили с фильтром марка')
    return render_template('brand.html', form=form, title='Автомобили с фильтром марка')

@app.route('/rent/price', methods=['GET', 'POST'])
@login_required
def price():
    form = PriceForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        if db_sess.query(Cars):
            cars = db_sess.query(Cars).filter(and_(Cars.price <= form.max_price.data, Cars.price >= form.min_price.data))
            return render_template('cars.html', cars=cars, title='Автомобили с фильтром цена', message='Выберите максимальную и минимальную цену')
    return render_template('price.html', form=form, title='Автомобили с фильтром цена')

@app.route('/rent/wheel', methods=['GET', 'POST'])
@login_required
def wheel():
    form = WheelForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        if db_sess.query(Cars):
            cars = db_sess.query(Cars).filter(Cars.wheel == form.wheel.data)
            return render_template('cars.html', cars=cars, title='Автомобили с фильтром расположение руля', message='Выберите расположение руля')
    return render_template('wheel.html', form=form, title='Автомобили с фильтром расположение руля')

@app.route('/rent/city', methods=['GET', 'POST'])
@login_required
def city():
    form = CityForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        if db_sess.query(Cars):
            cars = db_sess.query(Cars).filter(Cars.city == form.city.data)
            return render_template('cars.html', cars=cars, title='Автомобили с фильтром город', message='Выберите город')
    return render_template('city.html', form=form, title='Автомобили с фильтром город')

@app.route('/news/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_news(id):
    form = NewsForm()
    if request.method == "GET":
        db_sess = db_session.create_session()
        news = db_sess.query(News).filter(News.id == id,
                                          News.user == current_user
                                          ).first()
        if news:
            form.title.data = news.title
            form.content.data = news.content
        else:
            abort(404)
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        news = db_sess.query(News).filter(News.id == id,
                                          News.user == current_user
                                          ).first()
        if news:
            news.title = form.title.data
            news.content = form.content.data
            db_sess.commit()
            return redirect('/blog')
        else:
            abort(404)
    return render_template('news.html',
                           title='Редактирование новости',
                           form=form
                           )

@app.route('/news_delete/<int:id>', methods=['GET', 'POST'])
@login_required
def news_delet(id):
    db_sess = db_session.create_session()
    news = db_sess.query(News).filter(News.id == id,
                                      News.user == current_user
                                      ).first()
    if news:
        db_sess.delete(news)
        db_sess.commit()
        return redirect("/blog")
    else:
        abort(404)


if __name__ == '__main__':
    main()
