from flask_wtf import FlaskForm
from wtforms import IntegerField, SubmitField, StringField, SelectField
class YearForm(FlaskForm):
    year = IntegerField('Год')
    submit = SubmitField('Применить')

class BrandForm(FlaskForm):
    brand = StringField('Марка автомобиля')
    submit = SubmitField('Применить')

class PriceForm(FlaskForm):
    min_price = IntegerField('Минимальная цена')
    max_price = IntegerField('Максимальная цена')
    submit = SubmitField('Применить')

class WheelForm(FlaskForm):
    wheel = SelectField('Расположение руля', choices=[('Правый'), ('Левый')])
    submit = SubmitField('Применить')

class CityForm(FlaskForm):
    city = SelectField('Выберите город', choices=[('Екатеринбург'), ('Новый Уренгой')])
    submit = SubmitField('Применить')